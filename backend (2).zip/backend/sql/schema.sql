CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) UNIQUE,
  password VARCHAR(255),
  twofa_secret VARCHAR(255),
  twofa_enabled TINYINT DEFAULT 0
);
