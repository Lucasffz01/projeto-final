<?php
// CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

header("Content-Type: application/json");
require_once "config.php";

// Receber dados do Ionic
$data = json_decode(file_get_contents("php://input"), true);

$email = $data['email'] ?? '';
$senha = $data['senha'] ?? '';

// Validar campos
if (!$email || !$senha) {
    echo json_encode(["status" => "erro", "mensagem" => "Preencha todos os campos"]);
    exit;
}

// Buscar usuário no banco
$query = $conn->prepare("SELECT id, nome, email, senha FROM usuarios WHERE email = ?");
$query->bind_param("s", $email);
$query->execute();
$result = $query->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["status" => "erro", "mensagem" => "Usuário não encontrado"]);
    exit;
}

$usuario = $result->fetch_assoc();

// Verificar senha
if (!password_verify($senha, $usuario['senha'])) {
    echo json_encode(["status" => "erro", "mensagem" => "Senha incorreta"]);
    exit;
}

// Sucesso
unset($usuario['senha']); // não enviar senha
echo json_encode([
    "status" => "sucesso",
    "mensagem" => "Login efetuado com sucesso",
    "usuario" => $usuario
]);
?>
