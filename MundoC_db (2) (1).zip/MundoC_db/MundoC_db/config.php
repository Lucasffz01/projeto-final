<?php
$host = "ec2-user@ec2-3-231-221-65.compute-1.amazonaws.com";
$user = "admin";
$pass = "Lucas12345678";
$db   = "mundoc_db";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_errno) {
    die("Erro ao conectar ao banco: " . $conn->connect_error);
}
?>
