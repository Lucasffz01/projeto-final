import express from 'express';
import { register, login, enable2fa, verify2fa } from '../controllers/authController.js';
import { auth } from '../middleware/auth.js';
const router = express.Router();

router.post('/register', register);
router.post('/login', login);
router.post('/2fa/enable', auth, enable2fa);
router.post('/2fa/verify', verify2fa);

export default router;
