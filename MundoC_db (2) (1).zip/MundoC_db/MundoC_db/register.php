<?php
header("Access-Control-Allow-Origin: *"); // ou 'http://localhost:8100'
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

header("Content-Type: application/json");

require_once "config.php";

$data = json_decode(file_get_contents("php://input"), true);

$nome  = $data["nome"] ?? "";
$email = $data["email"] ?? "";
$senha = $data["senha"] ?? "";

// validar campos obrigatórios
if (!$nome || !$email || !$senha) {
    echo json_encode(["status" => "erro", "mensagem" => "Campos obrigatórios faltando"]);
    exit;
}

// verificar email duplicado
$check = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    echo json_encode(["status" => "erro", "mensagem" => "Email já cadastrado"]);
    exit;
}

$hash = password_hash($senha, PASSWORD_DEFAULT);

$query = $conn->prepare("INSERT INTO usuarios (nome,email,senha) VALUES (?,?,?)");
$query->bind_param("sss", $nome, $email, $hash);

if ($query->execute()) {
    echo json_encode(["status" => "sucesso", "mensagem" => "Usuário registrado com sucesso"]);
} else {
    echo json_encode(["status" => "erro", "mensagem" => "Erro ao registrar: " . $conn->error]);
}
?>
